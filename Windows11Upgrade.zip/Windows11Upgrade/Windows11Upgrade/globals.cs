﻿namespace Windows11Upgrade {
    internal static class globals {
        public static string isoPath = "";
        public static string downloadURL = "";
        public static string mountedDriveLetter = "";
    }
}